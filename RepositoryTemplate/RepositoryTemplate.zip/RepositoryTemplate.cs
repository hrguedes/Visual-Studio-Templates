﻿using Hrguedes.Atendor.Domain.Abstractions.Repositories;
using Hrguedes.Atendor.Domain.Application;
using Hrguedes.Atendor.Infra.Persistence.Context;
using Hrguedes.Atendor.Infra.Shared.Abstractions;

namespace $rootnamespace$;

public class $safeitemname$(AppDbContext context) : Repository<$fileinputname$>(context), I$safeitemname$
{

}
