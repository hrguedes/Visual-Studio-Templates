﻿using Hrguedes.Atendor.Infra.Shared.Abstractions;

namespace $rootnamespace$;

public interface $safeitemname$ : IService<$fileinputname$>
{

}
