﻿using Hrguedes.Atendor.Infra.Shared.Abstractions;

namespace $rootnamespace$;

public interface $safeitemname$ : IRepository<$fileinputname$>
{

}
