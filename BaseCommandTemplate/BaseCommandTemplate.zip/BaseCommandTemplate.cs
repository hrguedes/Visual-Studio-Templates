﻿using Hrguedes.Atendor.Infra.Shared.Commands;

namespace $rootnamespace$;

public class $safeitemname$ : BaseCommand<$fileinputname$Response>
{
}

